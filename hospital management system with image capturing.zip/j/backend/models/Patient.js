const mongoose = require('mongoose');

    // Yeh schema aapke "Appointment" form se match karta hai
    const patientSchema = new mongoose.Schema({
      // Yeh 'appointmentForm' se aa rahe hain
      pname: { type: String, required: true },
      mobile: { type: String, required: true },
      dept: { type: String, required: true },
      doctor: { type: String, required: true },
      date: { type: String }, // Ya 'Date' type bhi use kar sakte hain
      time: { type: String },
      notes: { type: String },
      patientPhoto: { type: String } // Base64 data string
    }, {
      // Taki 'createdAt' aur 'updatedAt' fields automatically ban jayein
      timestamps: true
    });

    const Patient = mongoose.model('Patient', patientSchema);

    module.exports = Patient;
