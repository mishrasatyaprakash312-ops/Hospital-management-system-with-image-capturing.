const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const Patient = require('./models/Patient');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ✅ MongoDB Connect
mongoose.connect('mongodb://127.0.0.1:27017/hospitalApp')
.then(() => console.log("✅ Database Connected"))
.catch(err => console.log(err));

// ✅ Important: Serve frontend folder
app.use(express.static(path.join(__dirname, '../frontend')));

// ✅ Route for opening index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend', 'index.html'));
});

// ✅ Save patient data
app.post('/api/patient', async (req, res) => {
  try {
    const patient = new Patient(req.body);
    await patient.save();
    res.json({ success: true, message: "Data saved successfully ✅" });
  } catch (error) {
    res.json({ success: false, message: error.message });
  }
});

// ✅ Start Server
app.listen(5000, () => console.log("🚀 Server running on http://localhost:5000"));
